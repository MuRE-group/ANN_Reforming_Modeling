Kinetic parameters: 

{
'AH_A':'[30000. 70000.]', 
'AH_B':'[30000. 70000.]', 
'Ea_SMR':'[ 70000. 120000.]', 
'Ea_SNR':'[ 60000. 100000.]', 
'Ea_WGS':'[ 60000. 100000.]', 
'K0_A':'[0.001 0.01 ]', 
'K0_B':'[0.0008 0.008 ]', 
'k0_SMR':'[5.e+10 2.e+11]', 
'k0_SNR':'[ 500000. 5000000.]', 
'k0_WGS':'[ 50000. 500000.]', 
}

Instances per model =  250

Models: 

'Dual Site Adsorption, Naphtha and Water'
'Same Site Adsorption, Naphtha and Water'
'Same Site Dissociative Adsorption, Naphtha and Water'
'Same Site Dissociative Adsorption, Naphtha and Water, Eley-Rideal'
'Single Adsorption, Water'
'Single Dissociative Adsorption, Water'
'Single Dissociative Adsorption, Water, Eley-Rideal'

Noise parameters:  

SigmaR =  0.0
SigmaC =  0.0
